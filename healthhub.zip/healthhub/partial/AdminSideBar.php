<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar w/ text</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li><a class="nav-link" href="AdminCreateCity.php"><span class="item-text"></span>Create New City</a></li>
                        <li><a class="nav-link" href="AdminCreateDoctor.php"> <span class="item-text">Create New Doctor</span></a></li>
                        <li><a class="nav-link" href="AdminCreatePatient.php"><span class="item-text"></span>Create New Patient</a></li>
                        <li><a class="nav-link" href="AdminUpdateDoctor.php"><span class="item-text"></span>Modify Doctor</a></li>
                        <li><a class="nav-link" href="AdminUpdatePatient.php"><span class="item-text"></span>Modifiy Patients</a></li>
                        <li><a class="nav-link" href="AdminDeleteDoctor.php"><span class="item-text"></span>Delete Doctor</a></li>
                        <li><a class="nav-link" href="AdminDeletePatient.php"><span class="item-text"></span>Delete Patient</a></li>
                        <li><a class="nav-link" href="AdminDeleteCity.php"><span class="item-text"></span>Delete Cities</a></li>
                        

                        <li><a class="nav-link" href="index.html" ><span class="item-text" color="black">Log Out</span></a></li>
                    
      </ul>
      <span class="navbar-text">
        Navbar
      </span>
    </div>
  </div>
</nav>