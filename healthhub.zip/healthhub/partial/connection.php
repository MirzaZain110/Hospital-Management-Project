<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment02";

$conn = mysqli_connect($host,$username,$password,$database);
if(!$conn)
{     
    die("Error". mysqli_connect_error());
}
// else{
//     echo "connected";
// }
?>