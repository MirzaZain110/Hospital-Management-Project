<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar w/ text</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li><a class="nav-link" href="DoctorProfile.php"> <span class="item-text">Veiw Profile</span></a></li>
                        <li><a class="nav-link" href="DoctorUpdateProfile.php"><span class="item-text">Update Profile</span></a></li>
                        <!-- <li><a class="nav-link" href="#"> <span class="item-text">Add Details</span></a></li> -->
                        <li><a class="nav-link" href="DoctorViewAppointment.php"> <span class="item-text"></span>View Appointments</a></li>
                        <li><a class="nav-link" href="#"> <span class="item-text"></span>Update Available Date</a></li>
                        <!-- <li><a class="nav-link" href="#"> <span class="item-text"></span></a></li> -->
                        <li><a class="nav-link" href="index.html" ><span class="item-text" color="black">Log Out</span></a></li>
                           
      </ul>
      <span class="navbar-text">
        Navbar
      </span>
    </div>
  </div>
</nav>