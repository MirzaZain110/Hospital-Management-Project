<?php
    include "partial/connection.php";
    session_start();
    include "partial/AdminSideBar.php";
    
   if($_SERVER["REQUEST_METHOD"] == "POST")
    {
      $city = $_POST['city'];
    $sql = "delete from `city` where cityname = '$city' ";
    mysqli_query($conn,$sql);
    // if(mysqli_num_rows($result))
    // {

    // }
    // echo "$Aid $Apassword";
    }
    // echo "<script>alert('Successfully updated');</script>";
?> 
<!doctype html>
<html lang="en">

<head>
  <title>Delete City</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
  <header>
    <!-- place navbar here -->
  </header>
  <main>

  </main>
  <footer>
    <!-- place footer here -->
  </footer>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
      <!-- This is the login screen  -->
      <br><br>
          <div class="card-body p-5 text-center">

            
<form class="mb-md-5 mt-md-4 pb-5" action="AdminDeleteCity.php" method="post" >
<!-- action="HomeAdmin.php" -->
<h2 class="fw-bold mb-2 text-uppercase">Delete City</h2>

<div class="form-outline form-white mb-4">
  <input type="text" id="city" name="city" class="form-control form-control-lg" />
  <label class="form-label" for="city">Enter City Name</label>
</div>

<button class="btn btn-outline-primary btn-lg px-5" type="submit" id="btn_save" name="btn_save">Save</button>


</form>


        

          </div>
        
<br><br>
</body>

</html>