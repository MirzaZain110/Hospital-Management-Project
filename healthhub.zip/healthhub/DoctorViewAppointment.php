<?php 
  include 'partial/connection.php';
  session_start();
 include 'partial/DoctorSideBar.php'; 
 $did = $_SESSION['Did'];
 $sql = "SELECT * FROM `appointment` where Did = '$did' ";
 $result = mysqli_query($conn, $sql);

?>
<!doctype html>
<html lang="en">

<head>
  <title>Veiw Appointments</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
  <header>
    <!-- place navbar here -->
  </header>
  <main>

  </main>
  <footer>
    <!-- place footer here -->
  </footer>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
          <div class="card-body p-5 text-center">
          <div class="row">
          <div class="col-md-4">
        
          <h2 class="m-2">Booked</h2>
<table class="table table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Aid</th>
      <th scope="col">Pid</th>
      <th scope="col">City</th>
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
   

            <?php
             if (mysqli_num_rows($result) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result)) 
                {
              ?> 
                  <tr>
                  <td><?php echo $row["App_id"]; ?></td>
                 <td><?php echo $row["Pid"]; ?></td>
                 <td><?php echo $row["cityname"]; ?></td> 
                 <td class="p-3"><?php echo $row["Date"]; ?></td>
                </tr>
             <?php
                }
              } else {
                echo "0 results";
              }
            ?>
          </tbody>
            </table>
          </div>
          </div>  
          </div>
         
</body>

</html>