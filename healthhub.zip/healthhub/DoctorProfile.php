
<?php 
include 'partial/connection.php';
 session_start();
include 'partial/DoctorSideBar.php'; 
$did = $_SESSION['Did'];
$sql = "SELECT * FROM `doctordetails` where Did = '$did' ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
 
    $name = $row["name"]; 
    $address = $row["Address"];
    $phone = $row["phone"];
    
  }
} else {
  echo "0 results";
}

?>


</body>
<!doctype html>
<html lang="en">

<head>
  <title>Profile</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
  <header>
    <!-- place navbar here -->
  </header>
  <main>

  </main>
  <footer>
    <!-- place footer here -->
  </footer>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>

\          <div class="card-body p-5 text-center">
          <div class="row">
          <div class="col-md-4">
            <!-- Profile Picture -->
            <!-- <img src="https://dummyimage.com/400x400/000/fff" alt="Profile Picture" class="img-fluid rounded-circle mb-3"> -->
            <img src="image/doctor.jfif" alt="Profile Picture" class="img-fluid rounded-circle mb-3">
            
            <h4>Contact</h4>
            <p>Social Media</p>
            <!-- Social Media Links -->
            <ul class="list-unstyled">
              <li><a href="#">Twitter</a></li>
              <li><a href="#">LinkedIn</a></li>
              <li><a href="#">Github</a></li>
            </ul>
          </div>
          <div class="col-md-8">
            <h2>About Me</h2>
            <p>Dr. <span><?php echo "$name";?></span> is a qualified Dermatologist in Lahore with over 15 years of experience in the field. </p>
            <ul class="list-group">
                <li class="list-group-item">ID : <span><?php echo "$did";?></span></li>
                <li class="list-group-item">Name : <span><?php echo "$name";?></span></li>
                <li class="list-group-item">Address : <span><?php echo "$address";?></span></li>
                <li class="list-group-item">Phone : <span><?php echo "$phone";?></span></li>
            </ul>
            <br>
            <h3>Doctor </h3>
            <p class="font-weight-bold">MBBS, FCPS (Dermatology), CAAAM (USA)</p>
            <p>Dermatologist </p>
            <p>Timing : 12:00 AM to 8 PM</p>
          </div>
        </div>
      </div>
          </div>
        

</body>

</html>