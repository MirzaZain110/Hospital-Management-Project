<?php
    include "partial/connection.php";
    session_start();
    include "partial/AdminSideBar.php";
    
   if($_SERVER["REQUEST_METHOD"] == "POST")
    {
      $dpass = $_POST['dpass'];
    $name = $_POST['name'];
    $Address = $_POST['address'];
    $phone = $_POST['phone']; 
    $sql = "Insert into `doctordetails` (Did,Dpassword,name,Address,Phone) VALUES ('','$dpass','$name','$Address','$phone')";
    mysqli_query($conn,$sql);
    // if(mysqli_num_rows($result))
    // {

    // }
    // echo "$Aid $Apassword";
    }
    $sql = "Select Max(did) As max_id from doctordetails";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $max = $row['max_id'];
    $max= $max+1;
    
    // echo "<script>alert('Successfully updated');</script>";
?> 
<!doctype html>
<html lang="en">

<head>
  <title>Create New Doctor</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
  <header>
    <!-- place navbar here -->
  </header>
  <main>

  </main>
  <footer>
    <!-- place footer here -->
  </footer>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
      <!-- This is the login screen  -->
      <br><br>
         <div class="card-body p-5 text-center">

            
<form class="mb-md-5 mt-md-4 pb-5" action="AdminCreateDoctor.php" method="post" >
<!-- action="HomeAdmin.php" -->
<h2 class="fw-bold mb-2 text-uppercase">Create New Doctor Account</h2>
<p class="text-white-50 mb-5">Account No : <?php echo "$max"; ?></p>

<div class="form-outline form-white mb-4">
  <input type="text" id="name" name="name" class="form-control form-control-lg" />
  <label class="form-label" for="name">Name</label>
</div>

<div class="form-outline form-white mb-4">
  <input type="text" id="address" name="address" class="form-control form-control-lg" />
  <label class="form-label" for="address">Address</label>
</div>

<div class="form-outline form-white mb-4">
  <input type="password" id="dpass" name="dpass" class="form-control form-control-lg" />
  <label class="form-label" for="dpass">Password</label>
</div>

<div class="form-outline form-white mb-4">
  <input type="text" id="phone" name="phone" class="form-control form-control-lg" />
  <label class="form-label" for="phone">Phone</label>
</div>

<button class="btn btn-outline-primary btn-lg px-5" type="submit" id="btn_save" name="btn_save">Save</button>


</form>


        

          </div>
      
<br><br>
</body>

</html>